//
//  Lab2.h
//  SELab2_1
//
//  Created by Emre Ozan Alkan on 10/7/13.
//  Copyright (c) 2013 Emre Ozan Alkan. All rights reserved.
//

#ifndef __SELab2_1__Lab2__
#define __SELab2_1__Lab2__

#include <iostream>

using namespace std;

// Our dumpvar for test
extern int dumvar;

int MyFunction1(int, int);

void MyFunction2(float);

#endif /* defined(__SELab2_1__Lab2__) */

function L = timeguy(L,board)
chrono = imread('chrono.bmp');
L(randi(5),randi(5)) = 4;
disp('hello')
for i = 1:5
    for j = 1:5            
            if L(i,j) == 4
                board((((i-1)*50+1):(i*50)),(((j-1)*50+1):(j*50)),:) = chrono;    
            end
    end
end

% Plotting the board
set(gcf,'Color',[0 0 0])
imshow(board)
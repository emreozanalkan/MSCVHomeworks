function state = invert(l)

if l == 1
    state = 0;
end

if l == 0
    state = 1;
end
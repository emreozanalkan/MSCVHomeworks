function B=thinning(A,TT)

B=A;
B=B-hitormiss(B,TT{1});
B=B-hitormiss(B,TT{2});
B=B-hitormiss(B,TT{3});
B=B-hitormiss(B,TT{4});
B=B-hitormiss(B,TT{5});
B=B-hitormiss(B,TT{6});
B=B-hitormiss(B,TT{7});